This is the README file for DriveBot.

Created by Craig Cheney

For more details see "stem.ccheney.net", or email "ccheney@mit.edu"  

Folder Descriptions
-------------------
AssemblyInstructions
	The Instructions folder contains the Bill of Materials, instructions for assembling the chassis, and instructions for the electrical connections.

CircuitBoards 
	This folder contains the EAGLE files for the three custom PCBs: the PowerSupplyUnit, the ResistorBoard, and the MotorDriver. STEM_Board is all of the PCBs combined, and the Gerber files generated for the PCB manufacturing. Note, no Forward/Backward annotation exists on STEM_Board.brd

LaserCutter
	Contains the Corel Design file, and the laser cutter file (.emf)

Pictures
	Screenshots and pictures of DriveBot. 

DriveBot.cywrk.Archive01.zip
	This is the file that contains the Creator 3.0 workspace for all of the files associated with DriveBot. In Creator, open the workspace "DriveBot.cywrk"

DriveBot_CAD.zip
	All of the solidworks parts, assemblies, and drawings. For the main file, open "Robot03.SLDASM"


Software Needed
----------------
PSoC Creator 3.0 -  "http://www.cypress.com/psoccreator/"
BlueTerm - Free for Android phones in the Play store
Solidworks - Good luck getting this. A work around is to get Autodesk Inventor, which is free for college students "http://www.autodesk.com/education/free-software/inventor-professional", however 