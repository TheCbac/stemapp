/* ========================================
 *
 * Copyright CRAIG CHENEY, 2014
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * BLUETOOTH CART DRIVING FILE 
 * ========================================
*/

void deviceInit();
void UART_MyInit();
void IDAC_MyInit();



/* [] END OF FILE */
