/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <main.h>

void deviceInit() 
{
    UART_MyInit();
    IDAC_MyInit();
    
    
}

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    deviceInit();
    
    
    uint8_t bluetoothData; //data to be recieved from bluetooth
    uint8_t currentOut=0x78; //default midvalue 
  
    
    IDAC_SetValue(currentOut);
 
    
    
    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        bluetoothData = UART_GetChar(); // wait for a byte to be sent
        
        if (bluetoothData > 0){
            UART_PutChar(bluetoothData);    //echo byte back 
            
            if (bluetoothData == 'q'){currentOut+=5;}
            else if (bluetoothData == 'p'){currentOut-=5;}
            
            
            IDAC_SetValue(currentOut);    //change the analog value out

            
        }
    }
}


// Initialize the UART
void UART_MyInit()
{
  UART_Start();  
}

// Initialize the Current DAC
void IDAC_MyInit()
{
    IDAC_Start();

}

/* [] END OF FILE */
