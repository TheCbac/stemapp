/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <main.h>

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    ADC_Start();
    PWM_Start();
    Clock_Start();
    
    uint8 duty =250;
    uint16 divider =1;
    
    
    ADC_StartConvert();
    PWM_WriteCompare(duty);
    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        duty=clip(ADC_GetResult16(0))*2;
        PWM_WriteCompare(duty);
        
        divider=1.0/ADC_GetResult16(1);
        Clock_SetDivider(divider);
        //CyDelay(500);
     
//        if(ADC_IsEndConversion(ADC_WAIT_FOR_RESULT)) {
//            duty=ADC_GetResult16(0);
//            PWM_WriteCompare(duty);
//            
//        }
    }
}

// Clip a number between 0 and 255
int8 clip(int8 num){
 if(num < 0) {
    return 0;}

else if (num >255) {
    return 255;}
else
    return num;
};





/* [] END OF FILE */
