/*******************************************************************************
* File Name: led_PIN_1.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_led_PIN_1_H) /* Pins led_PIN_1_H */
#define CY_PINS_led_PIN_1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "led_PIN_1_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    led_PIN_1_Write(uint8 value) ;
void    led_PIN_1_SetDriveMode(uint8 mode) ;
uint8   led_PIN_1_ReadDataReg(void) ;
uint8   led_PIN_1_Read(void) ;
uint8   led_PIN_1_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define led_PIN_1_DRIVE_MODE_BITS        (3)
#define led_PIN_1_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - led_PIN_1_DRIVE_MODE_BITS))
#define led_PIN_1_DRIVE_MODE_SHIFT       (0x00u)
#define led_PIN_1_DRIVE_MODE_MASK        (0x07u << led_PIN_1_DRIVE_MODE_SHIFT)

#define led_PIN_1_DM_ALG_HIZ         (0x00u << led_PIN_1_DRIVE_MODE_SHIFT)
#define led_PIN_1_DM_DIG_HIZ         (0x01u << led_PIN_1_DRIVE_MODE_SHIFT)
#define led_PIN_1_DM_RES_UP          (0x02u << led_PIN_1_DRIVE_MODE_SHIFT)
#define led_PIN_1_DM_RES_DWN         (0x03u << led_PIN_1_DRIVE_MODE_SHIFT)
#define led_PIN_1_DM_OD_LO           (0x04u << led_PIN_1_DRIVE_MODE_SHIFT)
#define led_PIN_1_DM_OD_HI           (0x05u << led_PIN_1_DRIVE_MODE_SHIFT)
#define led_PIN_1_DM_STRONG          (0x06u << led_PIN_1_DRIVE_MODE_SHIFT)
#define led_PIN_1_DM_RES_UPDWN       (0x07u << led_PIN_1_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define led_PIN_1_MASK               led_PIN_1__MASK
#define led_PIN_1_SHIFT              led_PIN_1__SHIFT
#define led_PIN_1_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define led_PIN_1_PS                     (* (reg32 *) led_PIN_1__PS)
/* Port Configuration */
#define led_PIN_1_PC                     (* (reg32 *) led_PIN_1__PC)
/* Data Register */
#define led_PIN_1_DR                     (* (reg32 *) led_PIN_1__DR)
/* Input Buffer Disable Override */
#define led_PIN_1_INP_DIS                (* (reg32 *) led_PIN_1__PC2)


#if defined(led_PIN_1__INTSTAT)  /* Interrupt Registers */

    #define led_PIN_1_INTSTAT                (* (reg32 *) led_PIN_1__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins led_PIN_1_H */


/* [] END OF FILE */
